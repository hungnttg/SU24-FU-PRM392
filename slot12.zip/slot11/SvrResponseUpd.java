package com.example.myapplication.slot11;

public class SvrResponseUpd {//GET
    private PrdUpd products;
    private String message;

    public PrdUpd getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
