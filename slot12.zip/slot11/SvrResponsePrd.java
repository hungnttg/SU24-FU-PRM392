package com.example.myapplication.slot11;

public class SvrResponsePrd {
    private Prd products;
    private String message;

    public Prd getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
