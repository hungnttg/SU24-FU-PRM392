package com.example.myapplication.slot11;

public class SvrResponseSelect {//GET
    private PrdSelect[] products;
    private String message;

    public PrdSelect[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
