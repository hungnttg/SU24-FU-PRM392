package com.example.myapplication.slot11;

public class SvrResponseDel { //GET
    private PrdDel products;
    private String message;

    public PrdDel getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
